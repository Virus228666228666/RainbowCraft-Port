package ru.V5Minecraft.RainbowCraft.blocks;

import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.block.IGrowable;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import ru.V5Minecraft.RainbowCraft.RainbowCraft;

import java.util.Random;

public class BlockRainbowHouse extends Block {
   public BlockRainbowHouse(String name) {
      super(Material.WOOD);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setCreativeTab(RainbowCraft.tabRainbowCraft);
   }

   public boolean onBlockActivated(World world, BlockPos pos, IBlockState state, EntityPlayer entity, EnumHand hand, EnumFacing side, float hitX, float hitY, float hitZ) {
      int i = pos.getX();
      int j = pos.getY();
      int k = pos.getZ();
      world.setBlockState(new BlockPos(i + 0, j + 0, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 0, j + 0, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 0, j + 0, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 0, j + 0, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 0, j + 0, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 0, j + 0, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 1, j + 0, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 0, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 0, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 0, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 5, j + 0, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 0, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 0, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 0, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 1, j + 0, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 0, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 0, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 0, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 5, j + 0, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 0, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 0, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 0, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 1, j + 0, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 0, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 0, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 0, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 5, j + 0, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 0, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 0, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 0, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 1, j + 0, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 0, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 0, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 0, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 5, j + 0, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 0, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 0, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 0, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 1, j + 0, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 0, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 0, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 0, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 5, j + 0, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 0, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 0, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 0, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 1, j + 0, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 0, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 0, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 0, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 5, j + 0, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 0, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 0, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 0, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 1, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 0, j + 1, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 0, j + 1, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 0, j + 1, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 0, j + 1, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 0, j + 1, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 8, j + 1, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 1, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 1, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 1, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 1, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 1, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 1, j + 1, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 1, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 1, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 1, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 5, j + 1, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 1, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 1, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 2, j + 1, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 1, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 1, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 5, j + 1, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 1, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 1, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 1, j + 0, k + 6), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 2, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 0, j + 3, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 0, j + 4, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 8, j + 2, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 3, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 4, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 2, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 0, j + 3, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 0, j + 4, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 8, j + 2, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 3, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 4, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 1, j + 1, k + 5), Block.getBlockFromName("minecraft:wooden_door").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 2, k + 4), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 0, j + 3, k + 4), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 0, j + 4, k + 4), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 4, k + 3), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 0, j + 4, k + 2), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 2, k + 1), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 0, j + 3, k + 1), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 0, j + 4, k + 1), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 8, j + 2, k + 4), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 3, k + 4), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 4, k + 4), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 8, j + 4, k + 3), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 4, k + 2), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 8, j + 2, k + 1), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 3, k + 1), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 4, k + 1), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 2, j + 2, k + 5), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 2, k + 5), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 2, j + 3, k + 5), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 3, k + 5), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 1, j + 3, k + 5), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 2, j + 4, k + 5), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 4, k + 5), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 1, j + 4, k + 5), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 4, j + 4, k + 5), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 4, k + 5), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 4, k + 5), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 7, j + 4, k + 5), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 3, k + 5), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 2, k + 5), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 2, k + 2), Block.getBlockFromName("minecraft:stained_glass_pane").getStateFromMeta(14));
      world.setBlockState(new BlockPos(i + 0, j + 2, k + 3), Block.getBlockFromName("minecraft:stained_glass_pane").getStateFromMeta(14));
      world.setBlockState(new BlockPos(i + 0, j + 3, k + 2), Block.getBlockFromName("minecraft:stained_glass_pane").getStateFromMeta(14));
      world.setBlockState(new BlockPos(i + 0, j + 3, k + 3), Block.getBlockFromName("minecraft:stained_glass_pane").getStateFromMeta(14));

      world.setBlockState(new BlockPos(i + 8, j + 2, k + 2), Block.getBlockFromName("minecraft:stained_glass_pane").getStateFromMeta(14));
      world.setBlockState(new BlockPos(i + 8, j + 2, k + 3), Block.getBlockFromName("minecraft:stained_glass_pane").getStateFromMeta(14));
      world.setBlockState(new BlockPos(i + 8, j + 3, k + 2), Block.getBlockFromName("minecraft:stained_glass_pane").getStateFromMeta(14));
      world.setBlockState(new BlockPos(i + 8, j + 3, k + 3), Block.getBlockFromName("minecraft:stained_glass_pane").getStateFromMeta(14));

      world.setBlockState(new BlockPos(i + 1, j + 2, k + 0), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 2, k + 0), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 2, k + 0), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 2, j + 2, k + 0), Block.getBlockFromName("minecraft:stained_glass_pane").getStateFromMeta(10));
      world.setBlockState(new BlockPos(i + 3, j + 2, k + 0), Block.getBlockFromName("minecraft:stained_glass_pane").getStateFromMeta(10));

      world.setBlockState(new BlockPos(i + 5, j + 2, k + 0), Block.getBlockFromName("minecraft:stained_glass_pane").getStateFromMeta(10));
      world.setBlockState(new BlockPos(i + 6, j + 2, k + 0), Block.getBlockFromName("minecraft:stained_glass_pane").getStateFromMeta(10));

      world.setBlockState(new BlockPos(i + 1, j + 3, k + 0), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 3, k + 0), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 3, k + 0), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 2, j + 3, k + 0), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 3, k + 0), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 3, k + 0), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 3, k + 0), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 2, j + 4, k + 0), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 4, k + 0), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 4, k + 0), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 4, k + 0), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 2, j + 4, k + 1), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 4, k + 1), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 4, k + 1), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 4, k + 1), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 4, j + 2, k + 5), Block.getBlockFromName("minecraft:stained_glass_pane").getStateFromMeta(10));
      world.setBlockState(new BlockPos(i + 5, j + 2, k + 5), Block.getBlockFromName("minecraft:stained_glass_pane").getStateFromMeta(10));
      world.setBlockState(new BlockPos(i + 6, j + 2, k + 5), Block.getBlockFromName("minecraft:stained_glass_pane").getStateFromMeta(10));

      world.setBlockState(new BlockPos(i + 4, j + 3, k + 5), Block.getBlockFromName("minecraft:stained_glass_pane").getStateFromMeta(10));
      world.setBlockState(new BlockPos(i + 5, j + 3, k + 5), Block.getBlockFromName("minecraft:stained_glass_pane").getStateFromMeta(10));
      world.setBlockState(new BlockPos(i + 6, j + 3, k + 5), Block.getBlockFromName("minecraft:stained_glass_pane").getStateFromMeta(10));

      world.setBlockState(new BlockPos(i + 1, j + 4, k + 0), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 4, k + 0), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 4, k + 0), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 1, j + 4, k + 1), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 4, k + 1), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 4, k + 1), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 1, j + 4, k + 4), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 4, k + 4), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 4, k + 4), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 2, j + 4, k + 4), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 4, k + 4), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 5, j + 4, k + 4), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 4, k + 4), Block.getBlockFromName("rainbowcraft:rainbowplanks").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 5, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 1, j + 5, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 5, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 5, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 5, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 5, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 5, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 5, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 5, k + 0), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 5, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 1, j + 5, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 5, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 5, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 5, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 5, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 5, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 5, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 5, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 5, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 1, j + 5, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 5, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 5, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 5, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 5, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 5, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 5, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 5, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 5, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 1, j + 5, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 5, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 5, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 5, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 5, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 5, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 5, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 5, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 5, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 1, j + 5, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 5, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 5, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 5, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 5, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 5, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 5, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 5, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 5, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 1, j + 5, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 5, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 5, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 5, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 5, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 5, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 5, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 5, k + 5), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 6, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 1, j + 6, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 6, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 6, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 6, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 6, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 6, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 6, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 6, k + 1), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 6, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 1, j + 6, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 6, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 6, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 6, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 6, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 6, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 6, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 6, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 6, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 1, j + 6, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 6, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 6, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 6, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 6, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 6, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 6, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 6, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 6, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 1, j + 6, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 6, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 6, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 6, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 6, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 6, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 6, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 6, k + 4), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 7, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 1, j + 7, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 7, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 7, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 7, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 7, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 7, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 7, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 7, k + 2), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 7, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 1, j + 7, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 7, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 7, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 7, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 7, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 7, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 7, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 7, k + 3), Block.getBlockFromName("rainbowcraft:rainbowcobblestone").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 5, k + 6), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 1, j + 5, k + 6), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 5, k + 6), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 5, k + 6), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 5, k + 6), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 5, k + 6), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 5, k + 6), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 5, k + 6), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 5, k + 6), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 6, k + 5), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 1, j + 6, k + 5), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 6, k + 5), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 6, k + 5), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 6, k + 5), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 6, k + 5), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 6, k + 5), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 6, k + 5), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 6, k + 5), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 7, k + 4), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 1, j + 7, k + 4), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 7, k + 4), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 7, k + 4), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 7, k + 4), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 7, k + 4), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 7, k + 4), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 7, k + 4), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 7, k + 4), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 8, k + 3), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 1, j + 8, k + 3), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 2, j + 8, k + 3), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 3, j + 8, k + 3), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 4, j + 8, k + 3), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 5, j + 8, k + 3), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 6, j + 8, k + 3), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 7, j + 8, k + 3), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());
      world.setBlockState(new BlockPos(i + 8, j + 8, k + 3), Block.getBlockFromName("rainbowcraft:rainbowstair").getDefaultState());

      world.setBlockState(new BlockPos(i + 0, j + 8, k + 2), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 1, j + 8, k + 2), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 2, j + 8, k + 2), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 3, j + 8, k + 2), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 4, j + 8, k + 2), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 5, j + 8, k + 2), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 6, j + 8, k + 2), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 7, j + 8, k + 2), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 8, j + 8, k + 2), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));

      world.setBlockState(new BlockPos(i + 0, j + 7, k + 1), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 1, j + 7, k + 1), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 2, j + 7, k + 1), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 3, j + 7, k + 1), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 4, j + 7, k + 1), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 5, j + 7, k + 1), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 6, j + 7, k + 1), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 7, j + 7, k + 1), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 8, j + 7, k + 1), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));

      world.setBlockState(new BlockPos(i + 0, j + 6, k + 0), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 1, j + 6, k + 0), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 2, j + 6, k + 0), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 3, j + 6, k + 0), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 4, j + 6, k + 0), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 5, j + 6, k + 0), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 6, j + 6, k + 0), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 7, j + 6, k + 0), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 8, j + 6, k + 0), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));

      world.setBlockState(new BlockPos(i + 0, j + 5, k - 1), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 1, j + 5, k - 1), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 2, j + 5, k - 1), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 3, j + 5, k - 1), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 4, j + 5, k - 1), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 5, j + 5, k - 1), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 6, j + 5, k - 1), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 7, j + 5, k - 1), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      world.setBlockState(new BlockPos(i + 8, j + 5, k - 1), Block.getBlockFromName("rainbowcraft:rainbowstair").getStateFromMeta(2));
      return true;
   }
}
