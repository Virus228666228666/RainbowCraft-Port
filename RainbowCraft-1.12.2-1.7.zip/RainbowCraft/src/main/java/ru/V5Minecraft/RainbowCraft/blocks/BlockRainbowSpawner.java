package ru.V5Minecraft.RainbowCraft.blocks;

import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.block.IGrowable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import ru.V5Minecraft.RainbowCraft.RainbowCraft;
import ru.V5Minecraft.RainbowCraft.Register.RegisterBlocks;

import java.util.Random;

public class BlockRainbowSpawner extends BlockBush implements IGrowable {
   public BlockRainbowSpawner(String name) {
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setCreativeTab(RainbowCraft.tabRainbowCraft);
   }

   @Override
   public boolean canGrow(World worldIn, BlockPos pos, IBlockState state, boolean isClient) {
      return true;
   }

   @Override
   public boolean canUseBonemeal(World worldIn, Random rand, BlockPos pos, IBlockState state) {
      return false;
   }

   @Override
   public void grow(World worldIn, Random rand, BlockPos pos, IBlockState state) {
   }

   public boolean onBlockActivated(World world, BlockPos pos, IBlockState state, EntityPlayer entity, EnumHand hand, EnumFacing side, float hitX, float hitY, float hitZ) {
      int i = pos.getX();
      int j = pos.getY();
      int k = pos.getZ();
      if (entity.inventory.getCurrentItem() != null && entity.inventory.getCurrentItem().getItem() == Items.DYE) {
            entity.inventory.clearMatchingItems(Items.DYE, -1, 1, null);
         if (Math.random() * 100.0D <= 4.15D) {
            world.setBlockState(new BlockPos(i + 0, j + 0, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            world.setBlockState(new BlockPos(i + 0, j + 1, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            world.setBlockState(new BlockPos(i + 0, j + 2, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));

            world.setBlockState(new BlockPos(i + 1, j + 0, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));
            world.setBlockState(new BlockPos(i + 1, j + 1, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));
            world.setBlockState(new BlockPos(i + 1, j + 2, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));

            world.setBlockState(new BlockPos(i + 2, j + 0, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));
            world.setBlockState(new BlockPos(i + 2, j + 1, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));
            world.setBlockState(new BlockPos(i + 2, j + 2, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));

            world.setBlockState(new BlockPos(i + 3, j + 0, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));
            world.setBlockState(new BlockPos(i + 3, j + 1, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));
            world.setBlockState(new BlockPos(i + 3, j + 2, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));

            world.setBlockState(new BlockPos(i + 4, j + 0, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));
            world.setBlockState(new BlockPos(i + 4, j + 1, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));
            world.setBlockState(new BlockPos(i + 4, j + 2, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));

            world.setBlockState(new BlockPos(i + 5, j + 0, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(11));
            world.setBlockState(new BlockPos(i + 5, j + 1, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(11));
            world.setBlockState(new BlockPos(i + 5, j + 2, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(11));

            world.setBlockState(new BlockPos(i + 6, j + 0, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(10));
            world.setBlockState(new BlockPos(i + 6, j + 1, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(10));
            world.setBlockState(new BlockPos(i + 6, j + 2, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(10));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 1, j + 3, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            world.setBlockState(new BlockPos(i + 1, j + 4, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));

            world.setBlockState(new BlockPos(i + 2, j + 3, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));
            world.setBlockState(new BlockPos(i + 2, j + 4, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));

            world.setBlockState(new BlockPos(i + 3, j + 3, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));
            world.setBlockState(new BlockPos(i + 3, j + 4, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));

            world.setBlockState(new BlockPos(i + 4, j + 3, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));
            world.setBlockState(new BlockPos(i + 4, j + 4, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));

            world.setBlockState(new BlockPos(i + 5, j + 3, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));
            world.setBlockState(new BlockPos(i + 5, j + 4, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));

            world.setBlockState(new BlockPos(i + 6, j + 3, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(11));
            world.setBlockState(new BlockPos(i + 6, j + 4, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(11));

            world.setBlockState(new BlockPos(i + 7, j + 3, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(10));
            world.setBlockState(new BlockPos(i + 7, j + 4, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(10));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 2, j + 5, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            world.setBlockState(new BlockPos(i + 2, j + 6, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));

            world.setBlockState(new BlockPos(i + 3, j + 5, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));
            world.setBlockState(new BlockPos(i + 3, j + 6, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));

            world.setBlockState(new BlockPos(i + 4, j + 5, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));
            world.setBlockState(new BlockPos(i + 4, j + 6, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));

            world.setBlockState(new BlockPos(i + 5, j + 5, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));
            world.setBlockState(new BlockPos(i + 5, j + 6, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));

            world.setBlockState(new BlockPos(i + 6, j + 5, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));
            world.setBlockState(new BlockPos(i + 6, j + 6, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));

            world.setBlockState(new BlockPos(i + 7, j + 6, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));
            world.setBlockState(new BlockPos(i + 7, j + 5, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(11));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 8, j + 5, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(10));
            world.setBlockState(new BlockPos(i + 9, j + 5, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(10));

            world.setBlockState(new BlockPos(i + 8, j + 6, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(11));
            world.setBlockState(new BlockPos(i + 9, j + 6, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(11));

            world.setBlockState(new BlockPos(i + 8, j + 7, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));
            world.setBlockState(new BlockPos(i + 9, j + 7, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));

            world.setBlockState(new BlockPos(i + 8, j + 8, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));
            world.setBlockState(new BlockPos(i + 9, j + 8, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));

            world.setBlockState(new BlockPos(i + 8, j + 9, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));
            world.setBlockState(new BlockPos(i + 9, j + 9, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));

            world.setBlockState(new BlockPos(i + 8, j + 10, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));
            world.setBlockState(new BlockPos(i + 9, j + 10, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));

            world.setBlockState(new BlockPos(i + 8, j + 11, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            world.setBlockState(new BlockPos(i + 9, j + 11, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 7, j + 7, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));
            world.setBlockState(new BlockPos(i + 6, j + 7, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));

            world.setBlockState(new BlockPos(i + 7, j + 8, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));
            world.setBlockState(new BlockPos(i + 6, j + 8, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));

            world.setBlockState(new BlockPos(i + 7, j + 9, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));
            world.setBlockState(new BlockPos(i + 6, j + 9, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));

            world.setBlockState(new BlockPos(i + 7, j + 10, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            world.setBlockState(new BlockPos(i + 6, j + 10, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 5, j + 9, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            world.setBlockState(new BlockPos(i + 5, j + 8, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));
            world.setBlockState(new BlockPos(i + 5, j + 7, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 4, j + 8, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            world.setBlockState(new BlockPos(i + 4, j + 7, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 3, j + 7, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 10, j + 12, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            world.setBlockState(new BlockPos(i + 11, j + 12, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            world.setBlockState(new BlockPos(i + 12, j + 12, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 10, j + 11, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));
            world.setBlockState(new BlockPos(i + 11, j + 11, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));
            world.setBlockState(new BlockPos(i + 12, j + 11, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 10, j + 10, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));
            world.setBlockState(new BlockPos(i + 11, j + 10, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));
            world.setBlockState(new BlockPos(i + 12, j + 10, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 10, j + 9, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));
            world.setBlockState(new BlockPos(i + 11, j + 9, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));
            world.setBlockState(new BlockPos(i + 12, j + 9, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 10, j + 8, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));
            world.setBlockState(new BlockPos(i + 11, j + 8, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));
            world.setBlockState(new BlockPos(i + 12, j + 8, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 10, j + 7, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(11));
            world.setBlockState(new BlockPos(i + 11, j + 7, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(11));
            world.setBlockState(new BlockPos(i + 12, j + 7, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(11));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 10, j + 6, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(10));
            world.setBlockState(new BlockPos(i + 11, j + 6, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(10));
            world.setBlockState(new BlockPos(i + 12, j + 6, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(10));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 13, j + 5, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(10));
            world.setBlockState(new BlockPos(i + 14, j + 5, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(10));

            world.setBlockState(new BlockPos(i + 13, j + 6, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(11));
            world.setBlockState(new BlockPos(i + 14, j + 6, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(11));

            world.setBlockState(new BlockPos(i + 13, j + 7, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));
            world.setBlockState(new BlockPos(i + 14, j + 7, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));

            world.setBlockState(new BlockPos(i + 13, j + 8, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));
            world.setBlockState(new BlockPos(i + 14, j + 8, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));

            world.setBlockState(new BlockPos(i + 13, j + 9, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));
            world.setBlockState(new BlockPos(i + 14, j + 9, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));

            world.setBlockState(new BlockPos(i + 13, j + 10, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));
            world.setBlockState(new BlockPos(i + 14, j + 10, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));

            world.setBlockState(new BlockPos(i + 13, j + 11, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            world.setBlockState(new BlockPos(i + 14, j + 11, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 22, j + 0, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            world.setBlockState(new BlockPos(i + 22, j + 1, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            world.setBlockState(new BlockPos(i + 22, j + 2, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));

            world.setBlockState(new BlockPos(i + 21, j + 0, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));
            world.setBlockState(new BlockPos(i + 21, j + 1, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));
            world.setBlockState(new BlockPos(i + 21, j + 2, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));

            world.setBlockState(new BlockPos(i + 20, j + 0, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));
            world.setBlockState(new BlockPos(i + 20, j + 1, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));
            world.setBlockState(new BlockPos(i + 20, j + 2, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));

            world.setBlockState(new BlockPos(i + 19, j + 0, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));
            world.setBlockState(new BlockPos(i + 19, j + 1, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));
            world.setBlockState(new BlockPos(i + 19, j + 2, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));

            world.setBlockState(new BlockPos(i + 18, j + 0, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));
            world.setBlockState(new BlockPos(i + 18, j + 1, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));
            world.setBlockState(new BlockPos(i + 18, j + 2, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));

            world.setBlockState(new BlockPos(i + 17, j + 0, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(11));
            world.setBlockState(new BlockPos(i + 17, j + 1, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(11));
            world.setBlockState(new BlockPos(i + 17, j + 2, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(11));

            world.setBlockState(new BlockPos(i + 16, j + 0, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(10));
            world.setBlockState(new BlockPos(i + 16, j + 1, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(10));
            world.setBlockState(new BlockPos(i + 16, j + 2, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(10));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 21, j + 3, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            world.setBlockState(new BlockPos(i + 21, j + 4, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));

            world.setBlockState(new BlockPos(i + 20, j + 3, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));
            world.setBlockState(new BlockPos(i + 20, j + 4, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));

            world.setBlockState(new BlockPos(i + 19, j + 3, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));
            world.setBlockState(new BlockPos(i + 19, j + 4, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));

            world.setBlockState(new BlockPos(i + 18, j + 3, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));
            world.setBlockState(new BlockPos(i + 18, j + 4, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));

            world.setBlockState(new BlockPos(i + 17, j + 3, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));
            world.setBlockState(new BlockPos(i + 17, j + 4, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));

            world.setBlockState(new BlockPos(i + 16, j + 3, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(11));
            world.setBlockState(new BlockPos(i + 16, j + 4, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(11));

            world.setBlockState(new BlockPos(i + 15, j + 3, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(10));
            world.setBlockState(new BlockPos(i + 15, j + 4, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(10));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 20, j + 5, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            world.setBlockState(new BlockPos(i + 20, j + 6, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));

            world.setBlockState(new BlockPos(i + 19, j + 5, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));
            world.setBlockState(new BlockPos(i + 19, j + 6, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));

            world.setBlockState(new BlockPos(i + 18, j + 5, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));
            world.setBlockState(new BlockPos(i + 18, j + 6, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));

            world.setBlockState(new BlockPos(i + 17, j + 5, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));
            world.setBlockState(new BlockPos(i + 17, j + 6, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));

            world.setBlockState(new BlockPos(i + 16, j + 5, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));
            world.setBlockState(new BlockPos(i + 16, j + 6, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));

            world.setBlockState(new BlockPos(i + 15, j + 6, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(3));
            world.setBlockState(new BlockPos(i + 15, j + 5, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(11));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 19, j + 7, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            world.setBlockState(new BlockPos(i + 18, j + 7, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));

            world.setBlockState(new BlockPos(i + 17, j + 7, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));
            world.setBlockState(new BlockPos(i + 16, j + 7, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));
            world.setBlockState(new BlockPos(i + 15, j + 7, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(5));

            world.setBlockState(new BlockPos(i + 16, j + 8, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));
            world.setBlockState(new BlockPos(i + 15, j + 8, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(4));

            world.setBlockState(new BlockPos(i + 17, j + 8, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));
            world.setBlockState(new BlockPos(i + 18, j + 8, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));

            world.setBlockState(new BlockPos(i + 17, j + 9, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));

            world.setBlockState(new BlockPos(i + 16, j + 9, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));
            world.setBlockState(new BlockPos(i + 15, j + 9, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(1));

            world.setBlockState(new BlockPos(i + 16, j + 10, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            world.setBlockState(new BlockPos(i + 15, j + 10, k + 0), Block.getBlockFromName("minecraft:stained_glass").getStateFromMeta(14));
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 0, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 1, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 2, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 3, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 4, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 5, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 6, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i + 0, j - 1, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 1, j - 1, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 2, j - 1, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 3, j - 1, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 4, j - 1, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 5, j - 1, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 6, j - 1, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i + 0, j - 1, k + 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 1, j - 1, k + 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 2, j - 1, k + 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 3, j - 1, k + 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 4, j - 1, k + 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 5, j - 1, k + 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 6, j - 1, k + 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i + 0, j - 1, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 1, j - 1, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 2, j - 1, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 3, j - 1, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 4, j - 1, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 5, j - 1, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 6, j - 1, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i + 0, j - 1, k - 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 1, j - 1, k - 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 2, j - 1, k - 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 3, j - 1, k - 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 4, j - 1, k - 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 5, j - 1, k - 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 6, j - 1, k - 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i - 1, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i - 1, j - 1, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i - 1, j - 1, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i - 2, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i + 7, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 7, j - 1, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 7, j - 1, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 8, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i + 0, j - 2, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 1, j - 2, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 2, j - 2, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 3, j - 2, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 4, j - 2, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 5, j - 2, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 6, j - 2, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i + 0, j - 2, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 1, j - 2, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 2, j - 2, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 3, j - 2, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 4, j - 2, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 5, j - 2, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 6, j - 2, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i + 0, j - 2, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 1, j - 2, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 2, j - 2, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 3, j - 2, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 4, j - 2, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 5, j - 2, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 6, j - 2, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i - 1, j - 2, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i + 7, j - 2, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            world.setBlockState(new BlockPos(i + 16, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 17, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 18, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 19, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 20, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 21, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 22, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i + 16, j - 1, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 17, j - 1, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 18, j - 1, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 19, j - 1, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 20, j - 1, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 21, j - 1, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 22, j - 1, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i + 16, j - 1, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 17, j - 1, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 18, j - 1, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 19, j - 1, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 20, j - 1, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 21, j - 1, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 22, j - 1, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i + 16, j - 1, k + 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 17, j - 1, k + 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 18, j - 1, k + 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 19, j - 1, k + 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 20, j - 1, k + 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 21, j - 1, k + 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 22, j - 1, k + 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i + 16, j - 1, k - 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 17, j - 1, k - 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 18, j - 1, k - 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 19, j - 1, k - 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 20, j - 1, k - 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 21, j - 1, k - 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 22, j - 1, k - 2), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i + 15, j - 1, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 15, j - 1, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 15, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 14, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i + 23, j - 1, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 23, j - 1, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 23, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 24, j - 1, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i + 15, j - 2, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 23, j - 2, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i + 16, j - 2, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 17, j - 2, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 18, j - 2, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 19, j - 2, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 20, j - 2, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 21, j - 2, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 22, j - 2, k - 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i + 16, j - 2, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 17, j - 2, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 18, j - 2, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 19, j - 2, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 20, j - 2, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 21, j - 2, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 22, j - 2, k + 1), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());

            world.setBlockState(new BlockPos(i + 16, j - 2, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 17, j - 2, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 18, j - 2, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 19, j - 2, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 20, j - 2, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 21, j - 2, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
            world.setBlockState(new BlockPos(i + 22, j - 2, k + 0), Block.getBlockFromName("rainbowcraft:cloud").getDefaultState());
         }
      }
      return true;
   }
}
