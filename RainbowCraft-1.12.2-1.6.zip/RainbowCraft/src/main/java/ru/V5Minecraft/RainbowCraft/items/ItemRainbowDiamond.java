package ru.V5Minecraft.RainbowCraft.items;

import net.minecraft.item.Item;
import ru.V5Minecraft.RainbowCraft.RainbowCraft;

public class ItemRainbowDiamond extends Item {
    public ItemRainbowDiamond() {
        this.setUnlocalizedName("rainbowDiamond");
        this.setRegistryName("rainbowDiamond");
        this.setCreativeTab(RainbowCraft.tabRainbowCraft);
    }
}
