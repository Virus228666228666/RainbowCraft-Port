package ru.V5Minecraft.RainbowCraft.entities;

import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraft.entity.EntityList;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import ru.V5Minecraft.RainbowCraft.RainbowCraft;

@EventBusSubscriber
public class ModEntities {
   private static int entityID = 0;
   public static void load() {
      createEntity(EntityLeprechaun.class, "leprechaun", 65280, 16711680);
   }

   private static void createEntity(Class entityClass, String entityName, int solidColor, int spotColor) {
      final ResourceLocation entityResourceLocation = new ResourceLocation("rainbowcraft", entityName);
      EntityRegistry.registerModEntity(entityResourceLocation, entityClass, entityName, entityID++, RainbowCraft.instance, 64, 1, true);
      EntityList.ENTITY_EGGS.put(entityResourceLocation, new EntityList.EntityEggInfo(entityResourceLocation, solidColor, spotColor));
   }
}
