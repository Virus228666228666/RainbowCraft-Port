package ru.V5Minecraft.RainbowCraft.entities;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class RenderLeprechaun extends RenderLiving<EntityLeprechaun> {
   private static final ResourceLocation LEPRECHAUN_TEXTURES = new ResourceLocation("rainbowcraft", "textures/entity/leprechaun.png");

   public RenderLeprechaun(RenderManager renderManagerIn, ModelBiped modelBipedIn, float shadowSizeIn) {
      super(renderManagerIn, modelBipedIn, shadowSizeIn);
   }

   @Override
   protected ResourceLocation getEntityTexture(EntityLeprechaun entity) {
      return LEPRECHAUN_TEXTURES;
   }
}
