package ru.V5Minecraft.RainbowCraft.entities;

import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.player.EntityPlayer;
import ru.V5Minecraft.RainbowCraft.Register.RegisterItems;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.item.Item;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class EntityLeprechaun extends EntityMob {
   public EntityLeprechaun(World worldIn) {
      super(worldIn);
      this.targetTasks.addTask(2, new EntityAINearestAttackableTarget<>(this, EntityPlayer.class, true));
   }

   @Override
   public boolean attackEntityFrom(DamageSource source, float amount) {
      if (super.attackEntityFrom(source, amount)) {
         if (source.getTrueSource() instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) source.getTrueSource();
            this.setAttackTarget(player);
         }
         return true;
      } else {
         return false;
      }
   }

   @Override
   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0D);
      this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(7.0D);
      this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.5D);
      this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(30.0D);
   }

   @Override
   protected void dropLoot(boolean wasRecentlyHit, int lootingModifier, DamageSource source) {
      Item i = RegisterItems.shards;
      int var3 = this.rand.nextInt(6) + 4;

      for(int var4 = 0; var4 < var3; ++var4) {
         this.dropItem(i, 1);
      }
   }
}
