package ru.V5Minecraft.RainbowCraft;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import ru.V5Minecraft.RainbowCraft.Proxy.CommonProxy;
import ru.V5Minecraft.RainbowCraft.Register.RegisterBlocks;
import ru.V5Minecraft.RainbowCraft.entities.ModEntities;
import ru.V5Minecraft.RainbowCraft.gui.MainMenuHandler;

@Mod(modid = "rainbowcraft", name = "RainbowCraft", version = "1.8")
public class RainbowCraft {
    public static final CreativeTabs tabRainbowCraft = new CreativeTabs("tabRainbowCraft") {
        public ItemStack getTabIconItem() {
            return new ItemStack(RegisterBlocks.BlockRainbowSpawner);
        }
    };

    @Mod.Instance("rainbowcraft")
    public static RainbowCraft instance;

    @SidedProxy(clientSide = "ru.V5Minecraft.RainbowCraft.Proxy.ClientProxy", serverSide = "ru.V5Minecraft.RainbowCraft.Proxy.CommonProxy")
    public static CommonProxy proxy;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event)
    {
        proxy.preInit(event);
        MinecraftForge.EVENT_BUS.register(new MainMenuHandler());
        //ModEntities.load();
    }

    @EventHandler
    public void init(FMLInitializationEvent event)
    {
        proxy.init(event);
    }

    @EventHandler
    public void postInit(FMLPostInitializationEvent event)
    {
        proxy.postInit(event);
    }
}
