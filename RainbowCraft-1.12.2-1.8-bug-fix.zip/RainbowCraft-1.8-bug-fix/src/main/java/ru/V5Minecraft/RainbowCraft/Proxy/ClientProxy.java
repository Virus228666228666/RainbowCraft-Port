package ru.V5Minecraft.RainbowCraft.Proxy;

import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import ru.V5Minecraft.RainbowCraft.Register.*;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInit(FMLPreInitializationEvent event) {
        super.preInit(event);
        /*RenderingRegistry.registerEntityRenderingHandler(EntityLeprechaun.class, new IRenderFactory<EntityLeprechaun>() {
            @Override
            public Render<? super EntityLeprechaun> createRenderFor(RenderManager manager) {
                return new RenderLeprechaun(manager, new ModelBiped(), 0.0F);
            }
        });*/
    }

    @Override
    public void init(FMLInitializationEvent event) {
        super.init(event);
        RegisterBlocks.registerRender();
    }

    @Override
    public void postInit(FMLPostInitializationEvent event) {
        super.postInit(event);
    }
}
