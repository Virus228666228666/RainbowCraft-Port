package ru.V5Minecraft.RainbowCraft.entities.fx;

import net.minecraft.client.particle.Particle;
import net.minecraft.world.World;

public class EntityRainbowBlastFX extends Particle {
   protected EntityRainbowBlastFX(World worldIn, double posXIn, double posYIn, double posZIn) {
      super(worldIn, posXIn, posYIn, posZIn);
   }
}
