package ru.V5Minecraft.RainbowCraft.entities;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;

public class EntityRainbowBall extends EntityThrowable {
   public EntityRainbowBall(World worldIn) {
      super(worldIn);
   }

   public EntityRainbowBall(World worldIn, EntityLivingBase throwerIn) {
      super(worldIn, throwerIn);
   }

   public EntityRainbowBall(World worldIn, double x, double y, double z) {
      super(worldIn, x, y, z);
   }

   @Override
   protected void onImpact(RayTraceResult result) {
      if (result.entityHit != null) {
         byte b0 = 5;
         result.entityHit.attackEntityFrom(DamageSource.causeThrownDamage(this, this.getThrower()), (float)b0);
      }

      for(int c = 0; c < 8; ++c) {
         this.world.spawnParticle(EnumParticleTypes.SNOWBALL, this.posX, this.posY, this.posZ, 0.0D, 0.0D, 0.0D);
      }

      if (!this.world.isRemote) {
         this.setDead();
      }
   }
}
