package ru.V5Minecraft.RainbowCraft.blocks;

import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.block.IGrowable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import ru.V5Minecraft.RainbowCraft.RainbowCraft;

import java.util.Random;

public class BlockRainbowSapling extends BlockBush implements IGrowable {
   public BlockRainbowSapling(String name) {
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setCreativeTab(RainbowCraft.RainbowCraft);
   }

   @Override
   public boolean canGrow(World worldIn, BlockPos pos, IBlockState state, boolean isClient) {
      return true;
   }

   @Override
   public boolean canUseBonemeal(World worldIn, Random rand, BlockPos pos, IBlockState state) {
      return false;
   }

   @Override
   public void grow(World worldIn, Random rand, BlockPos pos, IBlockState state) {
   }

   public boolean onBlockActivated(World world, BlockPos pos, IBlockState state, EntityPlayer entity, EnumHand hand, EnumFacing side, float hitX, float hitY, float hitZ) {
      int i = pos.getX();
      int j = pos.getY();
      int k = pos.getZ();
      if (entity.inventory.getCurrentItem() != null && entity.inventory.getCurrentItem().getItem() == Items.DYE) {
         if (entity instanceof EntityPlayer)
            entity.inventory.clearMatchingItems(Items.DYE, -1, 1, null);
         if (Math.random() * 100.0D <= 4.15D) {
            world.setBlockState(new BlockPos(i + 0, j + 0, k + 0), Block.getBlockFromName("rainbowcraft:rainbowlog").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 0, j + 1, k + 0), Block.getBlockFromName("rainbowcraft:rainbowlog").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 0, j + 2, k + 0), Block.getBlockFromName("rainbowcraft:rainbowlog").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 0, j + 3, k + 0), Block.getBlockFromName("rainbowcraft:rainbowlog").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 1, j + 1, k - 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 1, j + 1, k - 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 0, j + 1, k - 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 1, j + 1, k + 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 1, j + 1, k + 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 0, j + 1, k + 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 1, j + 1, k - 0), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 1, j + 1, k - 0), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 1, j + 2, k - 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 1, j + 2, k - 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 0, j + 2, k - 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 1, j + 2, k + 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 1, j + 2, k + 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 0, j + 2, k + 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 1, j + 2, k - 0), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 1, j + 2, k - 0), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 2, j + 1, k - 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 2, j + 1, k - 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 1, j + 1, k - 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 2, j + 1, k + 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 2, j + 1, k + 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 1, j + 1, k + 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 2, j + 1, k - 0), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 2, j + 1, k - 0), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 2, j + 2, k - 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 2, j + 2, k - 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 1, j + 2, k - 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 2, j + 2, k + 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 2, j + 2, k + 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 1, j + 2, k + 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 2, j + 2, k - 0), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 2, j + 2, k - 0), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 2, j + 1, k - 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 2, j + 1, k - 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 1, j + 1, k - 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 2, j + 1, k + 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 2, j + 1, k + 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 1, j + 1, k + 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 2, j + 1, k - 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 2, j + 1, k - 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 1, j + 1, k - 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 0, j + 1, k - 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 1, j + 2, k - 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 0, j + 2, k - 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 1, j + 2, k - 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 2, j + 2, k - 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 2, j + 2, k - 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 1, j + 2, k + 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 2, j + 2, k + 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 2, j + 2, k + 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 1, j + 2, k + 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 0, j + 2, k + 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 1, j + 1, k + 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 0, j + 1, k + 2), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 0, j + 4, k + 0), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 1, j + 3, k + 0), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 1, j + 3, k + 0), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 0, j + 3, k + 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 0, j + 3, k - 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 0, j + 4, k + 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 0, j + 4, k - 1), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i + 1, j + 4, k + 0), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
            world.setBlockState(new BlockPos(i - 1, j + 4, k + 0), Block.getBlockFromName("rainbowcraft:rainbowleaves").getStateFromMeta(0), 3);
         }
      }
      return true;
   }
}
