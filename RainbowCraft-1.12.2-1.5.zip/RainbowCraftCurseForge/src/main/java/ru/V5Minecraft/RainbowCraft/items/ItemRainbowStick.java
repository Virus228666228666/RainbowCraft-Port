package ru.V5Minecraft.RainbowCraft.items;

import net.minecraft.item.Item;
import ru.V5Minecraft.RainbowCraft.RainbowCraft;

public class ItemRainbowStick extends Item {
    public ItemRainbowStick() {
        this.setUnlocalizedName("rainbowStick");
        this.setRegistryName("rainbowStick");
        this.setCreativeTab(RainbowCraft.RainbowCraft);
    }
}
