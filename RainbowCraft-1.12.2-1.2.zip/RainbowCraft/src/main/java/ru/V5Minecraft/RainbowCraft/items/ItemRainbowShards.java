package ru.V5Minecraft.RainbowCraft.items;

import net.minecraft.item.Item;
import ru.V5Minecraft.RainbowCraft.RainbowCraft;

public class ItemRainbowShards extends Item {
    public ItemRainbowShards() {
        this.setUnlocalizedName("rainbowShards");
        this.setRegistryName("rainbowShards");
        this.setCreativeTab(RainbowCraft.RainbowCraft);
    }
}
